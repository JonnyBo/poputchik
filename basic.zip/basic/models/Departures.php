<?php

namespace app\models;

use yii\db\ActiveRecord;
use yii\db\Query;
use yii\caching\FileCache;

class Departures extends ActiveRecord
{
    public static function tableName()
    {
        return 'departures';
    }

    public static function totalStats($cacheDuration = 300, $driver_id = 0, $client_id = 0)
    {
        $cacheKey = 'Departures_totalStats';

        $cache = new FileCache;
        $stats = $cache->get($cacheKey);

        if ($stats === false) {
            $stats = array(
                'total' => '',
            );

            $query = Departures::find();

            $stats['total'] = $query->count();
            $stats['total_to_driver'] = $query->where(['driver_id' => $driver_id])->count();
            $stats['total_to_client'] = $query->where(['client_id' => $client_id])->count();
            //['avg_duration_calls'] = self::avgDurationCalls();
            //$stats['max_numbers_b'] = self::maxNumbersB();

            $cache->set($cacheKey, $stats,$cacheDuration);
        }

        return $stats;

    }

    public function create($fields)
    {
        $fields = $fields + array(
                'date',
                'departure_point',
                'arrival_point',
                'quantity',
                'client_id',
                'price',
                'flight_number',
                'driver_id',
            );


        $customer = new Departures();
        $customer->date = $fields['date'];
        $customer->departure_point = $fields['departure_point'];
        $customer->arrival_point = $fields['arrival_point'];
        $customer->quantity = $fields['quantity'];
        $customer->client_id = $fields['client_id'];
        $customer->price = $fields['price'];
        $customer->flight_number = $fields['flight_number'];
        $customer->driver_id = $fields['driver_id'];
        return $customer->save();
    }

    public function delete($all = false)
    {
        if ($all) {
            $customer = new Departures();
            return $customer->deleteAll('1=1');
        }
    }

}