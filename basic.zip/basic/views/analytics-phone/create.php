<h1>Лог выполнения (добавление а БД телефонных номеров)</h1>

<ul>
    <?php foreach ($results as $result): ?>
        <li>
            <?= $result . "\n" ?>
        </li>
    <?php endforeach; ?>
</ul>