<?php
use yii\helpers\Html;

$this->title = 'Analytics Phone';
$this->params['breadcrumbs'][] = $this->title;
?>

<?= Html::encode($message) ?>