<?php

class jqGrid_Exception_DB extends jqGrid_Exception
{
    protected $exception_type = 'db';
}